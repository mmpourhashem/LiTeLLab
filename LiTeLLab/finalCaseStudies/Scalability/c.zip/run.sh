java -jar litellab.jar AL8M-k9.txt -k 9
mv z3.output.txt AL8M-k9.z3.output.txt
mv litellab.output.txt AL8M-k9.output.txt


java -jar litellab.jar AL10M-k11.txt -k 11
mv z3.output.txt AL10M-k11.z3.output.txt
mv litellab.output.txt AL10M-k11.output.txt

java -jar litellab.jar AL12M-k13.txt -k 13
mv z3.output.txt AL12M-k13.z3.output.txt
mv litellab.output.txt AL12M-k13.output.txt

java -jar litellab.jar AL14M-k15.txt -k 15
mv z3.output.txt AL14M-k15.z3.output.txt
mv litellab.output.txt AL14M-k15.output.txt


java -jar litellab.jar AL16M-k17.txt -k 17
mv z3.output.txt AL16M-k17.z3.output.txt
mv litellab.output.txt AL16M-k17.output.txt


